import React from 'react';
import logo from '../webmotors.svg';

function Header(){
    return (
        <header className="App-header">
        <img src={logo} alt="logo" />
        </header>
        
    );
}


export default Header;